myfun <-
function(x){x*2}
